catalogo = {
'BK001': ['El Quijote', 'Miguel de Cervantes', 'físico', 1200, 'Editorial Planeta', 'español'],
'BK002': ['1984', 'George Orwell', 'digital', 328, 'Penguin', 'inglés'],
'BK003': ['Rayuela', 'Julio Cortázar', 'físico', 600, 'Sudamericana', 'español'],
'BK004': ['Sapiens', 'Yuval Noah Harari', 'digital', 450, 'Debate', 'inglés'],
}

inventario = {
'BK001': [15990, 3],
'BK002': [8990, 0],
'BK003': [18990, 7],
'BK004': [12500, 5],
}

def numero_entero():
    while True:
        try:
            numero=int(input("Ingrese el dígito"))
            return numero
        except:
            print("Ingrese un numero valido")




def stock_editorial(editorial):
    stock = 0
    for id, datos in catalogo.items():
        if datos[4].lower() == editorial.lower():
            stock = stock + inventario[id][1]
    print("El stock para la editoria", editorial, ": ", stock)


def buscar_por_precio(p_min , p_max):

    libros_en_rango = []
    
    for codigo, datos in catalogo.items():
        precio = inventario[codigo][0]
        stock= inventario [codigo][1]

        if p_min <= precio <= p_max and stock >0:
            titulo = datos[0]
            libros_en_rango.append((titulo, codigo))

    if libros_en_rango:
        libros_en_rango.sort()
        print("Libros disponibles en ese rango de precios:")
        for item in libros_en_rango:
            titulo = item[0]
            codigo= item[0]
            print(f"{titulo}{codigo}")
    else:
        print("No hay libros disponibles en ese rango de precios: ")



def actualizar_precio(codigo, nuevo_precio):
    if codigo in inventario:
        inventario[codigo][0] = nuevo_precio
        print(f"Precio actualizado para {codigo}.")
    else:
        print("El libro no existe!!")
        print("Precio actualizado!!")




def main():
    print("Librearía BookStation")
    while True:
        print("***MENU PRINCIPAL***")
        print("1.Stock por editorial")
        print("2.Buscar libros por precio")
        print("3.Actualizar el precio del libro")
        print("4.Salir")

        op= input("Ingrese la opcion")

        if op == "1":
            editorial = input("Ingrese el nombre de la editorial: ")
            stock_editorial(editorial)

        elif op== "2":
            print("Ingrese el precio mínimo")
            p_min =numero_entero()
            print("Ingrese el precio maximo")
            p_max =numero_entero()
            buscar_por_precio(p_min,p_max)
        
        elif op == "3":

            codigo = input("Ingrese el codigo del libro: ").upper()
            print("Ingrese el nuevo rpecio: ")
            nuevo_precio = numero_entero()
            actualizar_precio(codigo, nuevo_precio)

        elif op == "4":
            print("Programa finalizado")

            break

        else:
            print("Ingrese una opcion valida")
if __name__== "__main__":
    main()
